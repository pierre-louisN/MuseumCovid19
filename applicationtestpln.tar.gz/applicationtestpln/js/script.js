alert('Bienvenue Monsieur Cérin');
console.log("Ce programme JS vient d'être chargé");
$(document).ready(function()
{
	console.log("Le document est prêt");

	var clignotement = function(){ 
		if (document.getElementById('Clignotant').style.visibility=='visible'){ 
      			document.getElementById('Clignotant').style.visibility='hidden'; 
   		} 
   		else{ 
   			document.getElementById('Clignotant').style.visibility='visible'; 
   		} 
	}; 
	//on appelle la fonction toutes les 0.5 secondes 
	periode = setInterval(clignotement, 500); 


	console.log("La mise en place est finie. En attente d'événements...");
});
