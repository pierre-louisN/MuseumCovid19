<!DOCTYPE html>
<html>
 <head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="/nextcloud/apps/applicationtestpln/css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="/nextcloud/apps/applicationtestpln/js/script.js"></script>
  </head>
  <body> 
    <div id="Clignotant" style="visibility:visible;">Voici mon texte clignotant</div>
  </body>
</html>
